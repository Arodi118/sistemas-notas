<?php
session_start();
include 'config.php';  // Conectar con la base de datos

// Verificar si el usuario ya ha iniciado sesión y redirigirlo
if (isset($_SESSION['usuario_id'])) {
    $rol = $_SESSION['rol'];
    if ($rol == 'maestro') {
        header('Location: maestro.php');
        exit;
    } elseif ($rol == 'padre') {
        header('Location: encargado.php');
        exit;
    } elseif ($rol == 'alumno') {
        header('Location: alumno.php');
        exit;
    }
}

// Generar token CSRF si no existe
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['correo'], $_POST['password'], $_POST['csrf_token'], $_POST['g-recaptcha-response'])) {
        $correo = $_POST['correo'];
        $password = $_POST['password'];
        $csrf_token = $_POST['csrf_token'];
        
        // ReCAPTCHA Secret Key
        $secretKey = '6LcMSXkqAAAAAPgJbCLU7-okd9aKJXZu_53YhYZ4';
        $captcha = $_POST['g-recaptcha-response'];
        $ip = $_SERVER['REMOTE_ADDR'];
        
        // Validación de reCAPTCHA
        $response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret={$secretKey}&response={$captcha}&remoteip={$ip}");
        $atributos = json_decode($response, true);

        // Verificar el token CSRF
        if (!hash_equals($_SESSION['csrf_token'], $csrf_token)) {
            $error = "Error: Token CSRF no válido.";
        } elseif (empty($atributos) || !$atributos['success']) {
            $error = "Verifica el CAPTCHA.";
        } else {
            // Buscar al usuario en las tablas de maestros, encargados y alumnos
            $usuario = null;
            $rol = '';

            // Verificar en la tabla de maestros
            $sql_maestro = "SELECT * FROM maestros WHERE correo = ?";
            $stmt_maestro = $pdo->prepare($sql_maestro);
            $stmt_maestro->execute([$correo]);
            $usuario_maestro = $stmt_maestro->fetch();

            if ($usuario_maestro) {
                $usuario = $usuario_maestro;
                $rol = 'maestro';
            }

            // Verificar en la tabla de encargados si no se encontró en maestros
            if (!$usuario) {
                $sql_encargado = "SELECT * FROM encargados WHERE correo = ?";
                $stmt_encargado = $pdo->prepare($sql_encargado);
                $stmt_encargado->execute([$correo]);
                $usuario_encargado = $stmt_encargado->fetch();

                if ($usuario_encargado) {
                    $usuario = $usuario_encargado;
                    $rol = 'padre';
                }
            }

            // Verificar en la tabla de alumnos si no se encontró en maestros ni encargados
            if (!$usuario) {
                $sql_alumno = "SELECT * FROM alumnos WHERE correo = ?";
                $stmt_alumno = $pdo->prepare($sql_alumno);
                $stmt_alumno->execute([$correo]);
                $usuario_alumno = $stmt_alumno->fetch();

                if ($usuario_alumno) {
                    $usuario = $usuario_alumno;
                    $rol = 'alumno';
                }
            }

            // Verificar si se encontró el usuario en alguna tabla
            if ($usuario) {
                $password_stored = $usuario['password'];  // Contraseña almacenada

                // Validar si la contraseña ingresada es igual a la almacenada
                if ($password === $password_stored) {
                    // Contraseña válida
                    session_regenerate_id(true);  // Regenerar la sesión para evitar secuestro de sesión
                    $_SESSION['usuario_id'] = $usuario['id'];
                    $_SESSION['rol'] = $rol;

                    // Redirigir según el rol del usuario
                    if ($rol == 'maestro') {
                        header("Location: maestro.php");
                        exit;
                    } elseif ($rol == 'padre') {
                        header("Location: encargado.php");
                        exit;
                    } elseif ($rol == 'alumno') {
                        header("Location: alumno.php");
                        exit;
                    }
                } else {
                    // Contraseña incorrecta
                    $error = "Contraseña incorrecta. Asegúrate de estar ingresando la contraseña correcta.";
                }
            } else {
                $error = "Usuario no encontrado.";
            }
        }
    } else {
        $error = "Por favor, complete todos los campos.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <style>
        /* Estilos para el chatbot */
        .chat-container {
            width: 400px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            border: 1px solid #ccc;
            position: fixed;
            bottom: 20px;
            right: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .messages {
            max-height: 300px;
            overflow-y: auto;
            margin-bottom: 10px;
            padding: 10px;
            background-color: #f9f9f9;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Iniciar Sesión</h2>

    <?php if (!empty($error)): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="POST" action="login.php">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']); ?>">
        <div class="form-group">
            <label for="correo">Correo:</label>
            <input type="email" name="correo" id="correo" required>
        </div>

        <div class="form-group">
            <label for="password">Contraseña:</label>
            <input type="password" name="password" id="password" required>
        </div>

        <div class="form-group">
            <div class="g-recaptcha" data-sitekey="6LcMSXkqAAAAAHB0ZXf_lWybEdSakFIhjuEzIWyo"></div>
        </div>

        <button type="submit">Iniciar sesión</button>
    </form>
</div>

<!-- Chatbot -->
<div class="chat-container">
    <div class="messages" id="messages">
        <div>Chatbot: Hola, te guiaré a través del proceso de inicio de sesión.</div>
        <div>Chatbot: Por favor, ingresa tu correo electrónico en el campo correspondiente.</div>
    </div>
</div>

<script>
    let step = 0;

    // Verificar al instante cuando el usuario ingresa el correo
    document.getElementById('correo').addEventListener('input', function() {
        if (step === 0 && this.value !== '') {
            const messages = document.getElementById('messages');
            messages.innerHTML += `<div>Chatbot: Gracias. Ahora, ingresa tu contraseña.</div>`;
            step = 1;
        }
    });

    // Verificar al instante cuando el usuario ingresa la contraseña
    document.getElementById('password').addEventListener('input', function() {
        if (step === 1 && this.value !== '') {
            const messages = document.getElementById('messages');
            messages.innerHTML += `<div>Chatbot: Perfecto. Por último, completa el CAPTCHA.</div>`;
            step = 2;
        }
    });

    // Detectar el cambio en el CAPTCHA para completar el proceso
    document.querySelector('.g-recaptcha').addEventListener('focus', function() {
        if (step === 2) {
            const messages = document.getElementById('messages');
            messages.innerHTML += `<div>Chatbot: Todo listo. Ahora, haz clic en "Iniciar sesión" para continuar.</div>`;
            step = 3;
        }
    });
</script>

</body>
</html>
