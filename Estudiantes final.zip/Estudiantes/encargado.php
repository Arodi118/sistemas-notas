<?php
session_start();
include 'config.php';
use GuzzleHttp\Client;

try {
    // Verificar si el usuario es encargado
    if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] != 'padre') {
        echo "Acceso denegado.";
        exit;
    }

    $id_encargado = $_SESSION['usuario_id'];

    // Generar token CSRF si no existe
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    // Obtener alumnos asignados al encargado
    $sql_hijos = "SELECT a.* FROM alumnos a 
                  JOIN asignacion_encargado ae ON a.id = ae.id_alumno 
                  WHERE ae.id_encargado = ?";
    $stmt_hijos = $pdo->prepare($sql_hijos);
    $stmt_hijos->execute([$id_encargado]);
    $hijos = $stmt_hijos->fetchAll();

    // Obtener las notas de los hijos
    $notas_hijos = [];
    foreach ($hijos as $hijo) {
        $sql = "SELECT cursos.nombre AS curso, notas.nota, notas.fecha 
                FROM notas 
                JOIN cursos ON notas.id_curso = cursos.id 
                WHERE notas.id_alumno = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$hijo['id']]);
        $notas_hijos[$hijo['id']] = $stmt->fetchAll();
    }

    // Enviar mensaje al maestro
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['mensaje'])) {
        $mensaje = $_POST['mensaje'];

        // Llamar al chatbot para obtener una respuesta
        $respuesta_chatbot = obtenerRespuestaChatbot($mensaje);

        // Guardar el mensaje y la respuesta del chatbot
        $id_destinatario = $_POST['id_destinatario'];
        $sql_mensaje = "INSERT INTO chat (id_remitente, id_destinatario, mensaje, fecha) VALUES (?, ?, ?, NOW())";
        $stmt_mensaje = $pdo->prepare($sql_mensaje);
        $stmt_mensaje->execute([$id_encargado, $id_destinatario, $mensaje]);

        // Mostrar respuesta del chatbot
        echo $respuesta_chatbot;
    }

    // Función para obtener la respuesta del chatbot
    function obtenerRespuestaChatbot($mensaje) {
        global $apiKey;

        $client = new Client();

        try {
            $response = $client->post('https://api.openai.com/v1/chat/completions', [
                'headers' => [
                    'Authorization' => 'Bearer ' . $apiKey,
                    'Content-Type' => 'application/json'
                ],
                'json' => [
                    'model' => 'gpt-3.5-turbo',  // Modelo GPT
                    'messages' => [
                        ['role' => 'user', 'content' => $mensaje]
                    ],
                ]
            ]);

            $responseBody = json_decode($response->getBody(), true);
            return $responseBody['choices'][0]['message']['content'];

        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return "Hubo un error al procesar tu solicitud. Inténtalo de nuevo más tarde.";
        }
    }

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat con el Maestro</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>

<h2>Chat con el Maestro</h2>

<form method="POST" action="encargado.php">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']); ?>">
    
    <label for="id_destinatario">Seleccionar Maestro:</label>
    <select name="id_destinatario" required>
        <option value="">-- Selecciona un Maestro --</option>
        <?php foreach ($hijos as $hijo): ?>
            <option value="<?= $hijo['id_maestro'] ?>"><?= htmlspecialchars($hijo['nombre_maestro']) ?></option>
        <?php endforeach; ?>
    </select>

    <label for="mensaje">Mensaje:</label>
    <textarea name="mensaje" required placeholder="Escribe tu mensaje..."></textarea>

    <button type="submit">Enviar Mensaje</button>
</form>

<a href="logout.php">Cerrar sesión</a>

</body>
</html>
