<?php
session_start();
include 'config.php';

try {
    // Verificar si el usuario es maestro
    if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] != 'maestro') {
        echo "Acceso denegado.";
        exit;
    }

    $id_maestro = $_SESSION['usuario_id'];

    // Generar token CSRF si no existe
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    // Obtener alumnos asignados al maestro
    $sql_alumnos = "SELECT a.* FROM alumnos a 
                    JOIN asignacion_maestro am ON a.id = am.id_alumno 
                    WHERE am.id_maestro = ?";
    $stmt_alumnos = $pdo->prepare($sql_alumnos);
    $stmt_alumnos->execute([$id_maestro]);
    $alumnos = $stmt_alumnos->fetchAll();

    // Obtener los cursos
    $sql_cursos = "SELECT * FROM cursos";
    $stmt_cursos = $pdo->prepare($sql_cursos);
    $stmt_cursos->execute();
    $cursos = $stmt_cursos->fetchAll();

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            echo "Error: Token CSRF no válido.";
            exit;
        }

        $id_alumno = $_POST['id_alumno'];
        $id_curso = $_POST['id_curso'];
        $nota = $_POST['nota'];
        $comentario = $_POST['comentario'];

        // Validar nota
        if (!filter_var($nota, FILTER_VALIDATE_INT, ["options" => ["min_range" => 1, "max_range" => 100]])) {
            echo "Error: La nota debe ser un número entre 1 y 100.";
            exit;
        }

        // Verificar que el maestro tiene asignado al alumno
        $sql_verificar = "SELECT COUNT(*) FROM asignacion_maestro WHERE id_maestro = ? AND id_alumno = ?";
        $stmt_verificar = $pdo->prepare($sql_verificar);
        $stmt_verificar->execute([$id_maestro, $id_alumno]);
        $es_asignado = $stmt_verificar->fetchColumn();

        if (!$es_asignado) {
            echo "Error: No tienes permiso para asignar notas a este alumno.";
            exit;
        }

        // Insertar nota
        $sql = "INSERT INTO notas (id_alumno, id_curso, nota, comentario) VALUES (?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id_alumno, $id_curso, $nota, $comentario]);

        echo "Nota ingresada correctamente.";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ingresar Notas</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>

<h2>Ingresar Notas</h2>

<form method="POST" action="maestro.php">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']); ?>">
    <label for="id_alumno">Seleccionar Alumno:</label>
    <select name="id_alumno" required>
        <option value="">-- Selecciona un Alumno --</option>
        <?php foreach ($alumnos as $alumno): ?>
            <option value="<?= $alumno['id'] ?>"><?= htmlspecialchars($alumno['nombre'] . " " . $alumno['apellido']) ?></option>
        <?php endforeach; ?>
    </select>

    <label for="id_curso">Seleccionar Curso:</label>
    <select name="id_curso" required>
        <option value="">-- Selecciona un Curso --</option>
        <?php foreach ($cursos as $curso): ?>
            <option value="<?= $curso['id'] ?>"><?= htmlspecialchars($curso['nombre']) ?></option>
        <?php endforeach; ?>
    </select>

    <label for="nota">Nota (1-100):</label>
    <input type="number" name="nota" min="1" max="100" step="1" required>

    <label for="comentario">Comentario:</label>
    <textarea name="comentario" placeholder="Comentario sobre la nota"></textarea>

    <button type="submit">Ingresar Nota</button>
</form>

<a href="logout.php">Cerrar sesión</a>

</body>
</html>