<?php
session_start();
include 'config.php';

// Verificar si el usuario es alumno
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] != 'alumno') {
    echo "Acceso denegado.";
    exit;
}

$id_alumno = $_SESSION['usuario_id'];

// Obtener las notas del alumno
$sql = "SELECT cursos.nombre AS curso, notas.nota, notas.comentario, notas.fecha 
        FROM notas 
        JOIN cursos ON notas.id_curso = cursos.id 
        WHERE notas.id_alumno = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id_alumno]);
$notas = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notas del Alumno</title>
    <link rel="stylesheet" href="estilos.css">
    <style>
        /* Estilos básicos para el chatbot */
        .chat-container {
            position: fixed;
            bottom: 10px;
            right: 10px;
            background-color: #fff;
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 10px;
        }

        .messages {
            max-height: 200px;
            overflow-y: auto;
            margin-bottom: 10px;
            padding: 10px;
            background-color: #f9f9f9;
            border-radius: 5px;
            flex: 1;
        }

        .user-input {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .user-input input {
            width: 85%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .user-input button {
            padding: 10px 15px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .user-input button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<h2>Mis Notas</h2>
<?php foreach ($notas as $nota): ?>
    <p>Curso: <?= htmlspecialchars($nota['curso']) ?> - Nota: <?= htmlspecialchars($nota['nota']) ?> (<?= htmlspecialchars($nota['comentario']) ?>) - Fecha: <?= htmlspecialchars($nota['fecha']) ?></p>
<?php endforeach; ?>

<!-- Chatbot Integrado -->
<div class="chat-container">
    <div class="messages" id="messages">
        <div>Chatbot: Hola, soy tu asistente. ¿En qué puedo ayudarte con respecto a tus notas de curso?</div>
    </div>
    <div class="user-input">
        <input type="text" id="user-input" placeholder="Escribe tu pregunta..." autofocus>
        <button onclick="sendMessage()">Enviar</button>
    </div>
</div>

<script>
// Preguntas frecuentes y sus respuestas
const faqs = {
    "¿Cómo puedo ver mis notas?": "Tus notas ya están visibles en esta página. Simplemente revisa los detalles de cada curso.",
    "¿Cuándo se publican las notas finales?": "Las notas finales se publican al final del semestre, generalmente dentro de dos semanas después del examen final.",
    "¿Qué hago si tengo una duda sobre mi calificación?": "Si tienes dudas sobre tu calificación, puedes contactar a tu profesor a través del correo electrónico proporcionado en el curso.",
    "¿Las notas se actualizan regularmente?": "Sí, tus notas se actualizan cada vez que hay una nueva evaluación o examen. Revisa regularmente esta página."
};

function sendMessage() {
    const userInput = document.getElementById('user-input').value;
    const messages = document.getElementById('messages');

    if (userInput.trim() === '') {
        return; // No enviar mensajes vacíos
    }

    // Mostrar el mensaje del usuario en el chat
    messages.innerHTML += `<div><b>Tú:</b> ${userInput}</div>`;

    // Limpiar el campo de entrada
    document.getElementById('user-input').value = '';

    // Responder con base en las preguntas frecuentes
    const response = getResponse(userInput);
    messages.innerHTML += `<div><b>Chatbot:</b> ${response}</div>`;

    // Desplazar el chat hacia abajo
    messages.scrollTop = messages.scrollHeight;
}

function getResponse(userInput) {
    // Convertir la entrada del usuario a minúsculas para una búsqueda más sencilla
    const userQuestion = userInput.toLowerCase();

    // Buscar si la pregunta existe en las preguntas frecuentes
    for (const question in faqs) {
        if (userQuestion.includes(question.toLowerCase())) {
            return faqs[question];
        }
    }

    // Si no se encuentra la pregunta, respuesta predeterminada
    return "Lo siento, no entiendo esa pregunta. ¿Puedes intentar preguntarlo de otra manera?";
}
</script>
<a href="logout.php">Cerrar sesión</a>
</body>
</html>
