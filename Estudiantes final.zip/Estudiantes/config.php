<?php
// Configuración de la conexión a la base de datos con manejo de errores
$host = 'localhost';
$dbname = 'Sistema_notas';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error en la conexión a la base de datos: " . $e->getMessage());
}

// Desactivar errores PDO en la producción para mayor seguridad (muestra mensajes de error solo en desarrollo)
// error_reporting(0);
?>
